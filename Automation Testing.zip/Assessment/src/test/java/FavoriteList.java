import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;

public class FavoriteList {

    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        // Set up the WebDriver and open the browser
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toqa\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();

        // Maximize the browser window
        driver.manage().window().maximize();

        // Set up WebDriverWait with a timeout (e.g., 60 seconds)
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));

        driver.get("http://localhost:4200/login");
        driver.findElement(By.id("email")).sendKeys("emily.johnson@example.com");
        driver.findElement(By.id("password")).sendKeys("Test123!!");

        driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")).click();

    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }

    @Test
    public void TC_FL_001() {
        driver.get("http://localhost:4200/item/HlYEftc5UlZrzQjtLmnd");

        WebElement addToFavoriteButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//button[contains(@class, 'favorite-button')]")));
        addToFavoriteButton.click();

        WebElement favoriteListButton = driver.findElement(By.id("favoriteList"));
        favoriteListButton.click();

        WebElement favoriteItem = driver.findElement(By.xpath("//div[@class='favorite-item']"));
        Assert.assertTrue(favoriteItem.isDisplayed(), "Item was not added to the Favorite list.");
    }

    @Test
    public void TC_FL_002() {
        driver.get("http://localhost:4200/item/HlYEftc5UlZrzQjtLmnd");

        WebElement addToFavoriteButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//button[contains(@class, 'favorite-button')]")));
        addToFavoriteButton.click();

        // Attempt to add again and verify duplicate prevention
        addToFavoriteButton.click();

        WebElement errorMessage = driver.findElement(By.id("favoriteError"));
        Assert.assertTrue(errorMessage.isDisplayed(), "Error message did not appear when adding duplicate item.");
        Assert.assertEquals(errorMessage.getText(), "Item already exists in Favorite", "Error message text is incorrect.");
    }

    @Test
    public void TC_FL_003() {
        driver.get("http://localhost:4200/favourites");

        WebElement removeButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//button[contains(@class, 'remove-favorite-button')]")));
        removeButton.click();

        WebElement favoriteList = driver.findElement(By.id("favoriteList"));
        Assert.assertTrue(favoriteList.getText().contains("No items in Favorite"), "Item was not removed from Favorite list.");
    }

    @Test
    public void TC_FL_005() {
        driver.get("http://localhost:4200/favourites");

        WebElement clearFavoriteButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//button[contains(@class, 'clear-favorite-button')]")));
        clearFavoriteButton.click();

        WebElement favoriteList = driver.findElement(By.id("favoriteList"));
        Assert.assertTrue(favoriteList.getText().contains("No items in Favorite"), "Favorite list was not cleared.");
    }

    @Test
    public void TC_FL_007() {
        driver.get("http://localhost:4200/favourites");

        WebElement moveToCartButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//button[contains(@class, 'move-to-cart-button')]")));
        moveToCartButton.click();

        WebElement cartList = driver.findElement(By.id("cartList"));
        Assert.assertTrue(cartList.getText().contains("Item Name"), "Item was not moved to the cart.");
    }
}
