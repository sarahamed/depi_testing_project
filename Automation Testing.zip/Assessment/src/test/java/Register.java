import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class Register {
    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        // Set up the WebDriver and open the browser
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toqa\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();

        // Maximize the browser window
        driver.manage().window().maximize();

        // Set up WebDriverWait with a timeout (e.g., 10 seconds)
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        // Open the registration page (local URL)
        driver.get("http://localhost:4200/register");

    }

    @Test
    public void TC_R_001() {

        WebElement nameField = driver.findElement(By.name("displayName")); // Replace with actual locator
        nameField.sendKeys("John Doe3");

        // Step 7: Enter valid email
        WebElement emailField = driver.findElement(By.name("email")); // Replace with actual locator
        emailField.sendKeys("john.doe3@example.com");

        // Step 8: Enter valid password
        WebElement passwordField = driver.findElement(By.id("password")); // Replace with actual locator
        passwordField.sendKeys("1234567");

        // Step 9: Click on the "Register" button
        WebElement registerSubmitButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Replace with actual locator
        registerSubmitButton.click();

        try {
            // Wait for the alert to be present and handle it
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            Alert alert = wait.until(ExpectedConditions.alertIsPresent());

            // Print the alert text
            System.out.println("Alert text: " + alert.getText());

            // Accept the alert (click 'OK')
            alert.accept();
        } catch (NoAlertPresentException e) {
            System.out.println("No alert present.");
        } catch (UnhandledAlertException e) {
            System.out.println("Unhandled alert present: " + e.getAlertText());
            driver.switchTo().alert().accept();  // Accept the unexpected alert
        } catch (TimeoutException e) {
            System.out.println("Alert did not appear within the timeout period.");
        } catch (NoSuchElementException e) {
            System.out.println("The element with ' Registration successful' text was not found.");
        }
    }
    @Test
    public void TC_R_002() {

        WebElement nameField = driver.findElement(By.name("displayName")); // Replace with actual locator
        nameField.clear();

        // Step 7: Enter valid email
        WebElement emailField = driver.findElement(By.name("email")); // Replace with actual locator
        emailField.sendKeys("john.doe3@example.com");

        // Step 8: Enter valid password
        WebElement passwordField = driver.findElement(By.id("password")); // Replace with actual locator
        passwordField.sendKeys("1234567");

        // Step 9: Click on the "Register" button
        WebElement registerSubmitButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Replace with actual locator

        // Step 7: Check if the login button is clickable
        boolean isClickable = false;
        try {
            isClickable = registerSubmitButton.isEnabled();
        } catch (NoSuchElementException e) {
            System.out.println("Register button not found.");
        }

        // Assert that the login button is not clickable
        Assert.assertFalse(isClickable, "The Register button should not be clickable when the email field is empty.");
    }

    @Test
    public void TC_R_003() {
        // Step 6: Enter invalid Name
        WebElement nameField = driver.findElement(By.name("displayName"));
        nameField.sendKeys("Emily Johnson123");

        // Step 7: Enter valid email
        WebElement emailField = driver.findElement(By.name("email"));
        emailField.sendKeys("emily.johnson@example.com");

        // Step 8: Enter valid password
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("Test123!!");

        WebElement registerSubmitButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Replace with actual locator
        registerSubmitButton.click();

        try {
            // Wait for the alert to be present and handle it
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            Alert alert = wait.until(ExpectedConditions.alertIsPresent());

            // Print the alert text
            System.out.println("Alert text: " + alert.getText());

            // Accept the alert (click 'OK')
            alert.accept();
        } catch (NoAlertPresentException e) {
            System.out.println("No alert present.");
        } catch (UnhandledAlertException e) {
            System.out.println("Unhandled alert present: " + e.getAlertText());
            driver.switchTo().alert().accept();  // Accept the unexpected alert
        } catch (TimeoutException e) {
            System.out.println("Alert did not appear within the timeout period.");
        } catch (NoSuchElementException e) {
            System.out.println("The element with ' something went wrong' text was not found.");
        }
    }

    @Test
    public void TC_R_004() {
        // Step 6: Enter invalid Name
        WebElement nameField = driver.findElement(By.name("displayName"));
        nameField.sendKeys("Emily@Johnson!!");

        // Step 7: Enter valid email
        WebElement emailField = driver.findElement(By.name("email"));
        emailField.sendKeys("emily.johnson@example.com");

        // Step 8: Enter valid password
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("Test123!!");

        WebElement registerSubmitButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Replace with actual locator
        registerSubmitButton.click();

        try {
            // Wait for the alert to be present and handle it
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            Alert alert = wait.until(ExpectedConditions.alertIsPresent());

            // Print the alert text
            System.out.println("Alert text: " + alert.getText());

            // Accept the alert (click 'OK')
            alert.accept();
        } catch (NoAlertPresentException e) {
            System.out.println("No alert present.");
        } catch (UnhandledAlertException e) {
            System.out.println("Unhandled alert present: " + e.getAlertText());
            driver.switchTo().alert().accept();  // Accept the unexpected alert
        } catch (TimeoutException e) {
            System.out.println("Alert did not appear within the timeout period.");
        } catch (NoSuchElementException e) {
            System.out.println("The element with ' something went wrong' text was not found.");
        }
    }

    @Test
    public void TC_R_005() {
        // Step 6: Enter invalid Name
        WebElement nameField = driver.findElement(By.name("displayName"));
        nameField.sendKeys("Emily Johnson123");

        // Step 7: Enter valid email
        WebElement emailField = driver.findElement(By.name("email"));
        emailField.clear();

        // Step 8: Enter valid password
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("Test123!!");

        // Step 9: Click on the "Register" button
        WebElement registerSubmitButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Replace with actual locator

        // Step 7: Check if the login button is clickable
        boolean isClickable = false;
        try {
            isClickable = registerSubmitButton.isEnabled();
        } catch (NoSuchElementException e) {
            System.out.println("Register button not found.");
        }

        // Assert that the login button is not clickable
        Assert.assertFalse(isClickable, "The register button should not be clickable when the email field is empty.");

    }

    @Test
    public void TC_R_006() {
        // Step 6: Enter invalid Name
        WebElement nameField = driver.findElement(By.name("displayName"));
        nameField.sendKeys("Emily Johnson");

        // Step 7: Enter valid email
        WebElement emailField = driver.findElement(By.name("email"));
        emailField.sendKeys("emily.johnson@");

        // Step 8: Enter valid password
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("Test123!!");

        WebElement registerSubmitButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Replace with actual locator
        registerSubmitButton.click();

        try {
            // Wait for the alert to be present and handle it
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            Alert alert = wait.until(ExpectedConditions.alertIsPresent());

            // Print the alert text
            System.out.println("Alert text: " + alert.getText());

            // Accept the alert (click 'OK')
            alert.accept();
        } catch (NoAlertPresentException e) {
            System.out.println("No alert present.");
        } catch (UnhandledAlertException e) {
            System.out.println("Unhandled alert present: " + e.getAlertText());
            driver.switchTo().alert().accept();  // Accept the unexpected alert
        } catch (TimeoutException e) {
            System.out.println("Alert did not appear within the timeout period.");
        } catch (NoSuchElementException e) {
            System.out.println("The element with ' something went wrong' text was not found.");
        }
    }

    @Test
    public void TC_R_007() {
        // Step 6: Enter invalid Name
        WebElement nameField = driver.findElement(By.name("displayName"));
        nameField.sendKeys("Emily Johnson");

        // Step 7: Enter valid email
        WebElement emailField = driver.findElement(By.name("email"));
        emailField.sendKeys("emily.johnson@example.com");

        // Step 8: Enter valid password
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.sendKeys("Test123!!");

        WebElement registerSubmitButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Replace with actual locator
        registerSubmitButton.click();

        try {
            // Wait for the alert to be present and handle it
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            Alert alert = wait.until(ExpectedConditions.alertIsPresent());

            // Print the alert text
            System.out.println("Alert text: " + alert.getText());

            // Accept the alert (click 'OK')
            alert.accept();
        } catch (NoAlertPresentException e) {
            System.out.println("No alert present.");
        } catch (UnhandledAlertException e) {
            System.out.println("Unhandled alert present: " + e.getAlertText());
            driver.switchTo().alert().accept();  // Accept the unexpected alert
        } catch (TimeoutException e) {
            System.out.println("Alert did not appear within the timeout period.");
        } catch (NoSuchElementException e) {
            System.out.println("The element with ' something went wrong' text was not found.");
        }
    }

    @Test
    public void TC_R_008() {
        // Step 6: Enter invalid Name
        WebElement nameField = driver.findElement(By.name("displayName"));
        nameField.sendKeys("Emily Johnson");

        // Step 7: Enter valid email
        WebElement emailField = driver.findElement(By.name("email"));
        emailField.sendKeys("emily.johnson@example.com");

        // Step 8: Enter valid password
        WebElement passwordField = driver.findElement(By.id("password"));
        passwordField.clear();

        // Step 9: Click on the "Register" button
        WebElement registerSubmitButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Replace with actual locator

        // Step 7: Check if the login button is clickable
        boolean isClickable = false;
        try {
            isClickable = registerSubmitButton.isEnabled();
        } catch (NoSuchElementException e) {
            System.out.println("Register button not found.");
        }

        // Assert that the login button is not clickable
        Assert.assertFalse(isClickable, "The register button should not be clickable when the email field is empty.");
    }

    @AfterMethod
    public void tearDown() {
        // Close the browser
        if (driver != null) {
            driver.quit();
        }
    }
}
