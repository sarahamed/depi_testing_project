import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

public class Search {
    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toqa\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("http://localhost:4200/home");
    }

    @AfterMethod
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void TC_S_001() {
        WebElement searchBar = driver.findElement(By.name("itemName"));
        searchBar.sendKeys("Lip Gloss");
        WebElement searchButton = driver.findElement(By.xpath("//button[@type='submit']"));
        searchButton.click();
        //Check if the search results container exists
        WebElement searchResultsContainer = driver.findElement(By.xpath("//app-search-results"));


        //  Verify if search results are displayed or the page is blank
        if (searchResultsContainer.getText().isEmpty()) {
            Assert.fail("The page loaded is blank. No search results or error message found.");
        } else {
            // Check if there are any search results within the container
            List<WebElement> searchResults = searchResultsContainer.findElements(By.tagName("div"));  // Adjust the tag or class based on actual structure

            if (searchResults.isEmpty()) {
                Assert.fail("No search results found, though the page loaded.");
            }
        }
    }

    @Test
    public void TC_S_002() {
        WebElement searchBar = driver.findElement(By.name("itemName"));
        searchBar.sendKeys("Lip");
        WebElement searchButton = driver.findElement(By.xpath("//button[@type='submit']"));
        searchButton.click();
        //Check if the search results container exists
        WebElement searchResultsContainer = driver.findElement(By.xpath("//app-search-results"));

        //  Verify if search results are displayed or the page is blank
        if (searchResultsContainer.getText().isEmpty()) {
            Assert.fail("The page loaded is blank. No search results or error message found.");
        } else {
            // Check if there are any search results within the container
            List<WebElement> searchResults = searchResultsContainer.findElements(By.tagName("div"));  // Adjust the tag or class based on actual structure

            if (searchResults.isEmpty()) {
                Assert.fail("No search results found, though the page loaded.");
            }
        }
    }

    @Test
    public void TC_S_003() {
        WebElement searchBar = driver.findElement(By.name("itemName"));
        searchBar.sendKeys("XYZ");
        WebElement searchButton = driver.findElement(By.xpath("//button[@type='submit']"));
        searchButton.click();
        //Check if the search results container exists
        WebElement searchResultsContainer = driver.findElement(By.xpath("//app-search-results"));


        //  Verify if search results are displayed or the page is blank
        if (searchResultsContainer.getText().isEmpty()) {
            Assert.fail("The page loaded is blank. No search results or error message found.");
        } else {
            // Check if there are any search results within the container
            List<WebElement> searchResults = searchResultsContainer.findElements(By.tagName("div"));  // Adjust the tag or class based on actual structure

            if (searchResults.isEmpty()) {
                Assert.fail("No search results found, though the page loaded.");
            }
        }
    }

    @Test
    public void TC_S_004() {

        WebElement searchOptionDropdown = driver.findElement(By.name("searchOption"));
        Select selectSearchOption = new Select(searchOptionDropdown);
        selectSearchOption.selectByValue("category");


        WebElement searchBar = driver.findElement(By.name("category"));
        searchBar.sendKeys("Toy");

        WebElement searchButton = driver.findElement(By.xpath("//button[@type='submit']"));
        searchButton.click();

        List<WebElement> searchResults = driver.findElements(By.cssSelector("div.item-container"));

        boolean categoryFound =true;
        for (WebElement result : searchResults) {
            WebElement itemCategory = result.findElement(By.cssSelector(".item-category"));

            if (itemCategory.getText().contains("Category:Toy")) {
                break;
            }
        }

        Assert.assertTrue(categoryFound, "No search result with category 'Toy' was found.");
    }


    @Test
    public void TC_S_005() {
        WebElement searchBar = driver.findElement(By.name("itemName"));
        searchBar.sendKeys("Car, Makeup");
        WebElement searchButton = driver.findElement(By.xpath("//button[@type='submit']"));
        searchButton.click();
        //Check if the search results container exists
        WebElement searchResultsContainer = driver.findElement(By.xpath("//app-search-results"));

        //  Verify if search results are displayed or the page is blank
        if (searchResultsContainer.getText().isEmpty()) {
            Assert.fail("The page loaded is blank. No search results or error message found.");
        } else {
            // Check if there are any search results within the container
            List<WebElement> searchResults = searchResultsContainer.findElements(By.tagName("div"));

            if (searchResults.isEmpty()) {
                Assert.fail("No search results found, though the page loaded.");
            }
        }
    }

    @Test
    public void TC_S_006() {
        WebElement searchOptionDropdown = driver.findElement(By.name("searchOption"));
        Select selectSearchOption = new Select(searchOptionDropdown);
        selectSearchOption.selectByValue("location");

        WebElement searchBar = driver.findElement(By.name("location"));
        searchBar.sendKeys("cairo");

        List<WebElement> searchResults = driver.findElements(By.cssSelector("div.item-container"));

        boolean categoryFound =true;
        for (WebElement result : searchResults) {
            WebElement itemCategory = result.findElement(By.cssSelector(".item-location"));

            if (itemCategory.getText().contains("Location: cairo")) {
                break;
            }
        }
        Assert.assertTrue(categoryFound, "Products in 'Cairo' location were not found.");
    }

    @Test
    public void TC_S_007() {
        WebElement searchOptionDropdown = driver.findElement(By.name("searchOption"));
        Select selectSearchOption = new Select(searchOptionDropdown);
        selectSearchOption.selectByValue("price");

        WebElement min = driver.findElement(By.name("minPrice"));
        min.sendKeys("100");
        WebElement max = driver.findElement(By.name("maxPrice"));
        max.sendKeys("500");

        List<WebElement> searchResults = driver.findElements(By.cssSelector("div.item-container"));

        boolean itemFound =true;
        for (WebElement result : searchResults) {
            WebElement itemCategory = result.findElement(By.cssSelector(".item-price"));

            if (itemCategory.getText().contains("Price:")) {
                break;
            }
        }
        Assert.assertTrue(itemFound, "No Items with this price range");
    }

    @Test
    public void TC_S_008() {
        WebElement searchOptionDropdown = driver.findElement(By.name("searchOption"));
        Select selectSearchOption = new Select(searchOptionDropdown);
        selectSearchOption.selectByValue("price");

        WebElement min = driver.findElement(By.name("minPrice"));
        min.sendKeys("3");
        WebElement max = driver.findElement(By.name("maxPrice"));
        max.sendKeys("10");

        List<WebElement> searchResults = driver.findElements(By.cssSelector("div.item-container"));

        boolean itemFound =false;
        for (WebElement result : searchResults) {
            WebElement itemCategory = result.findElement(By.cssSelector(".item-price"));

            if (itemCategory.getText().contains("Price:")) {
                itemFound = true;
                break;
            }
        }
        Assert.assertTrue(itemFound, "No Items with this price range");
    }


    @Test
    public void TC_S_010() {
        WebElement searchBar = driver.findElement(By.name("itemName"));
        searchBar.sendKeys("@#%*");
        WebElement searchButton = driver.findElement(By.xpath("//button[@type='submit']"));
        searchButton.click();
        //Check if the search results container exists
        WebElement searchResultsContainer = driver.findElement(By.xpath("//app-search-results"));

        //  Verify if search results are displayed or the page is blank
        if (searchResultsContainer.getText().isEmpty()) {
            Assert.fail("The page loaded is blank. No search results or error message found.");
        } else {
            // Check if there are any search results within the container
            List<WebElement> searchResults = searchResultsContainer.findElements(By.tagName("div"));  // Adjust the tag or class based on actual structure

            if (searchResults.isEmpty()) {
                Assert.fail("No search results found, though the page loaded.");
            }
        }
    }

    @Test
    public void TC_S_012() {
        WebElement searchOptionDropdown = driver.findElement(By.name("searchOption"));
        Select selectSearchOption = new Select(searchOptionDropdown);
        selectSearchOption.selectByValue("location");

        WebElement searchBar = driver.findElement(By.name("location"));
        searchBar.sendKeys("Cairo");

        WebElement searchButton = driver.findElement(By.xpath("//button[@type='submit']"));
        searchButton.click();

        WebElement searchResultsContainer = driver.findElement(By.xpath("//app-search-results"));

        //  Verify if search results are displayed or the page is blank
        if (searchResultsContainer.getText().isEmpty()) {
            Assert.fail("The page loaded is blank. No search results or error message found.");
        } else {
            // Check if there are any search results within the container
            List<WebElement> searchResults = searchResultsContainer.findElements(By.tagName("div"));

            if (searchResults.isEmpty()) {
                Assert.fail("No search results found, though the page loaded.");
            }
        }
    }

    @Test
    public void TC_S_013() {

        WebElement searchOptionDropdown = driver.findElement(By.name("searchOption"));
        Select selectSearchOption = new Select(searchOptionDropdown);
        selectSearchOption.selectByValue("category");


        WebElement searchBar = driver.findElement(By.name("category"));
        searchBar.sendKeys("Toy");

        WebElement searchButton = driver.findElement(By.xpath("//button[@type='submit']"));
        searchButton.click();

        WebElement searchResult = driver.findElement(By.cssSelector("div.item-container"));
        searchResult.click();

        Assert.fail("The item is not clickable");
    }

}
