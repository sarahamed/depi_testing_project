import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;

public class Login {

    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        // Set up the WebDriver and open the browser
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toqa\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();

        // Maximize the browser window
        driver.manage().window().maximize();

        // Set up WebDriverWait with a timeout (e.g., 10 seconds)
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));
        // Open the registration page (local URL)
        driver.get("http://localhost:4200/login");

    }

    @Test
    public void TC_LI_003() {


        // Step 1: Enter valid email
        driver.findElement(By.id("email")).sendKeys("emily.johnson@example.com");

        // Step 2: Enter valid password
        driver.findElement(By.id("password")).sendKeys("Test123!!");

        // Step 3: Click on the "Register" button
        driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")).click();

    }

    @Test
    public void TC_LI_004() {
        // Step 1: Enter valid email
        driver.findElement(By.id("email")).sendKeys("emily.johnson@example.com");

        // Step 2: Enter valid password
        driver.findElement(By.id("password")).sendKeys("test12345##");

        // Step 3: Click on the "Login" button
        driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")).click();

        try {
            // Wait for the alert to be present and handle it
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            Alert alert = wait.until(ExpectedConditions.alertIsPresent());

            // Print the alert text
            System.out.println("Alert text: " + alert.getText());

            // Accept the alert (click 'OK')
            alert.accept();
        } catch (NoAlertPresentException e) {
            System.out.println("No alert present.");
        } catch (UnhandledAlertException e) {
            System.out.println("Unhandled alert present: " + e.getAlertText());
            driver.switchTo().alert().accept();  // Accept the unexpected alert
        } catch (TimeoutException e) {
            System.out.println("Alert did not appear within the timeout period.");
        } catch (NoSuchElementException e) {
            System.out.println("The element with 'something went wrong' text was not found.");
        }
    }

    @Test
    public void TC_LI_005() {
        // Step 1: Enter valid email
        driver.findElement(By.id("email")).sendKeys("emily.johnson@");

        // Step 2: Enter valid password
        driver.findElement(By.id("password")).sendKeys("Test123!!");

        // Step 3: Click on the "Login" button
        driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")).click();

        try {
            // Wait for the alert to be present and handle it
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            Alert alert = wait.until(ExpectedConditions.alertIsPresent());

            // Print the alert text
            System.out.println("Alert text: " + alert.getText());

            // Accept the alert (click 'OK')
            alert.accept();
        } catch (NoAlertPresentException e) {
            System.out.println("No alert present.");
        } catch (UnhandledAlertException e) {
            System.out.println("Unhandled alert present: " + e.getAlertText());
            driver.switchTo().alert().accept();  // Accept the unexpected alert
        } catch (TimeoutException e) {
            System.out.println("Alert did not appear within the timeout period.");
        } catch (NoSuchElementException e) {
            System.out.println("The element with 'something went wrong' text was not found.");
        }
    }

    @Test
    public void TC_LI_006() {
        // Step 1: Enter valid email
        driver.findElement(By.id("email")).sendKeys("john.doe@example.com");

        // Step 2: Enter valid password
        driver.findElement(By.id("password")).sendKeys("Test123!!");

        // Step 3: Click on the "Login" button
        driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")).click();

        try {
            // Wait for the alert to be present and handle it
            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
            Alert alert = wait.until(ExpectedConditions.alertIsPresent());

            // Print the alert text
            System.out.println("Alert text: " + alert.getText());

            // Accept the alert (click 'OK')
            alert.accept();
        } catch (NoAlertPresentException e) {
            System.out.println("No alert present.");
        } catch (UnhandledAlertException e) {
            System.out.println("Unhandled alert present: " + e.getAlertText());
            driver.switchTo().alert().accept();  // Accept the unexpected alert
        } catch (TimeoutException e) {
            System.out.println("Alert did not appear within the timeout period.");
        } catch (NoSuchElementException e) {
            System.out.println("The element with 'something went wrong' text was not found.");
        }
    }

    @Test
    public void TC_LI_007() {

        // Step 4: Leave the email field empty
        WebElement emailField = driver.findElement(By.id("email")); // Replace with the actual email field locator
        emailField.clear(); // Ensure the field is empty

        // Step 5: Enter a valid password
        WebElement passwordField = driver.findElement(By.id("password")); // Replace with the actual password field locator
        passwordField.sendKeys("Test123!!");

        // Step 6: Attempt to click on the login button
        WebElement loginButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Replace with actual login button locator

        // Step 7: Check if the login button is clickable
        boolean isClickable = false;
        try {
            isClickable = loginButton.isEnabled();
        } catch (NoSuchElementException e) {
            System.out.println("Login button not found.");
        }

        // Assert that the login button is not clickable
        Assert.assertFalse(isClickable, "The login button should not be clickable when the email field is empty.");
    }

    @Test
    public void TC_LI_008() {

        // Step 4: Leave the email field empty
        WebElement emailField = driver.findElement(By.id("email")); // Replace with the actual email field locator
        emailField.sendKeys("emily.johnson@example.com"); // Ensure the field is empty

        // Step 5: Enter a valid password
        WebElement passwordField = driver.findElement(By.id("password")); // Replace with the actual password field locator
        passwordField.clear();

        // Step 6: Attempt to click on the login button
        WebElement loginButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Replace with actual login button locator

        // Step 7: Check if the login button is clickable
        boolean isClickable = false;
        try {
            isClickable = loginButton.isEnabled();
        } catch (NoSuchElementException e) {
            System.out.println("Login button not found.");
        }

        // Assert that the login button is not clickable
        Assert.assertFalse(isClickable, "The login button should not be clickable when the email field is empty.");
    }

    @AfterMethod
    public void tearDown() {
        // Close the browser
        if (driver != null) {
            driver.quit();
        }
    }
}
