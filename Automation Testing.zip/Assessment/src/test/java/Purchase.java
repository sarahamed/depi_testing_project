import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import java.time.Duration;
import java.util.List;

public class Purchase {
    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        // Set up the WebDriver and open the browser
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toqa\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();

        // Maximize the browser window
        driver.manage().window().maximize();

        // Set up WebDriverWait with a timeout (e.g., 60 seconds)
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));

        driver.get("http://localhost:4200/login");
        driver.findElement(By.id("email")).sendKeys("emily.johnson@example.com");
        driver.findElement(By.id("password")).sendKeys("Test123!!");


        driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")).click();


        JavascriptExecutor jsExecutor = (JavascriptExecutor) driver;
        jsExecutor.executeScript("return window.getAllAngularTestabilities().findIndex(x=>!x.isStable()) === -1");


        WebElement profileButton = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//mat-expansion-panel-header[contains(@class, 'mat-expansion-panel-header') and @role='button']")
        ));
        profileButton.click();

        WebElement myProfileButton = driver.findElement(By.xpath("//button[text()='My profile']"));
        myProfileButton.click();

    }

    @AfterTest
    public void teardown() {
        driver.quit();
    }

    @Test
    public void TC_P_001() {
        WebElement myPurchasesButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[text()='My Purchases']")
        ));
        myPurchasesButton.click();

        List<WebElement> orderCards = driver.findElements(By.xpath("//div[contains(@class, 'card ng-star-inserted')]"));

        for (WebElement orderCard : orderCards) {

            WebElement orderImage = orderCard.findElement(By.xpath(".//img[@class='card-image']"));
            Assert.assertTrue(orderImage.isDisplayed(), "Order image is not displayed.");
            Assert.assertFalse(orderImage.getAttribute("src").isEmpty(), "Order image source is missing.");

            WebElement postedBy = orderCard.findElement(By.xpath(".//p[contains(@class, 'card-text') and contains(text(), 'Posted by:')]"));
            Assert.assertTrue(postedBy.isDisplayed(), "Posted by information is not displayed.");
            Assert.assertFalse(postedBy.getText().replace("Posted by:", "").trim().isEmpty(), "Posted by information is empty.");

            WebElement price = orderCard.findElement(By.xpath(".//p[contains(@class, 'card-text') and contains(text(), 'Price:')]"));
            Assert.assertTrue(price.isDisplayed(), "Price information is not displayed.");
            Assert.assertTrue(price.getText().contains("$"), "Price format is incorrect.");
        }
    }

    @Test
    public void TC_P_002() {
        WebElement myPurchasesButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[text()='My Purchases']")
        ));
        myPurchasesButton.click();

        WebElement firstPurchaseDate = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.className("purchase-date")));
        String dateText = firstPurchaseDate.getText();

        // Assuming date format MM/DD/YYYY, verify with regex
        String dateFormatPattern = "^\\d{2}/\\d{2}/\\d{4}$";
        Assert.assertTrue(dateText.matches(dateFormatPattern), "Date format is incorrect: " + dateText);
    }

    @Test
    public void TC_P_004() {
        WebElement LogOutButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[text()='LogOut']")
        ));
        LogOutButton.click();

        driver.get("http://localhost:4200/Purchases");

        String currentUrl = driver.getCurrentUrl();
        Assert.assertTrue(currentUrl.contains("/login"), "User was not redirected to the login page.");
    }

    @Test
    public void TC_P_006() {

        WebElement myPurchasesButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[text()='My Purchases']")
        ));
        myPurchasesButton.click();

        WebElement firstPurchaseProduct = driver.findElement(By.className("purchase-product-name"));
        WebElement firstPurchaseDescription = driver.findElement(By.className("purchase-product-description"));

        Assert.assertTrue(firstPurchaseProduct.isDisplayed(), "Product name is not displayed.");
        Assert.assertTrue(firstPurchaseDescription.isDisplayed(), "Product description is not displayed.");

    }

    @Test
    public void TC_P_007() {

        WebElement myPurchasesButton = wait.until(ExpectedConditions.elementToBeClickable(
                By.xpath("//button[text()='My Purchases']")
        ));
        myPurchasesButton.click();

        WebElement orderCard = wait.until(ExpectedConditions.visibilityOfElementLocated(
                By.xpath("//div[contains(@class, 'card ng-star-inserted')]")));
        WebElement deleteButton = orderCard.findElement(By.xpath(".//button[contains(@class, 'delete-button')]"));

        deleteButton.click();

        driver.navigate().refresh();

        List<WebElement> orderCards = driver.findElements(By.xpath("//div[contains(@class, 'card ng-star-inserted')]"));
        Assert.assertTrue(orderCards.isEmpty() || !orderCards.contains(orderCard), "Product was not deleted from purchase history.");

    }
}
