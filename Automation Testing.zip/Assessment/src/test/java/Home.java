import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;
import java.util.List;

public class Home {
    WebDriver driver;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        // Set up the WebDriver and open the browser
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\Toqa\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe");
        driver = new ChromeDriver();

        // Maximize the browser window
        driver.manage().window().maximize();

        // Set up WebDriverWait with a timeout (e.g., 60 seconds)
        wait = new WebDriverWait(driver, Duration.ofSeconds(60));

        // Open the home page
        driver.get("http://localhost:4200/home");
    }

    @Test
    public void TC_H_001() {
        // Find the element by class name
        WebElement navLogo = driver.findElement(By.className("nav-logo"));

        // Extract the text of the element
        String actualTitle = navLogo.getText();

        // Define the expected title
        String expectedTitle = "Home";

        // Assert that the text matches the expected title
        Assert.assertEquals(actualTitle, expectedTitle, "Home page did not load as expected");
    }


    @Test
    public void TC_H_002() {
        // Navigate to the login page
        driver.get("http://localhost:4200/login");

        // Add steps for logging in
        driver.findElement(By.id("email")).sendKeys("emily.johnson@example.com");
        driver.findElement(By.id("password")).sendKeys("Test123!!");
        driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")).click();

        // After login, navigate to the home page
        driver.get("http://localhost:4200/home");
        WebElement navLogo = driver.findElement(By.className("nav-logo"));
        String actualTitle = navLogo.getText();
        String expectedTitle = "Home";
        Assert.assertEquals(actualTitle, expectedTitle, "Home page did not load as expected");
    }

    @Test
    public void TC_H_003() {
        driver.findElement(By.xpath("//button[@class='nav-sell-button']")).click();
        driver.findElement(By.className("nav-logo")).click();
        String expectedTitle = "Home";
        String actualTitle = driver.findElement(By.className("nav-logo")).getText();
        Assert.assertEquals(actualTitle, expectedTitle, "Navigation to Home page failed");
    }

    @Test
    public void TC_H_004() {
        // Example: Verify a specific link
        WebElement someLink = driver.findElement(By.linkText("Some Link Text")); // Adjust based on the actual link text
        Assert.assertTrue(someLink.isDisplayed(), "Link is not visible on the Home page");
        someLink.click();

        // Validate that the new page has loaded after clicking the link
        String expectedTitle = "Expected Page Title"; // Adjust accordingly
        String actualTitle = driver.getTitle();
        Assert.assertEquals(actualTitle, expectedTitle, "Link did not redirect to the expected page");
    }

    @Test
    public void TC_H_005() {
        // Simulate a desktop screen size (1024x768)
        driver.manage().window().setSize(new Dimension(1024, 768));

        // Wait for the page to adjust to the new size (optional, based on your page's behavior)
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("nav-logo")));  // Adjust to an appropriate condition

        // Add validation code for desktop size elements
        WebElement desktopNavLogo = driver.findElement(By.className("nav-logo"));
        Assert.assertTrue(desktopNavLogo.isDisplayed(), "The navigation logo should be visible on desktop size.");

        // Simulate a mobile screen size (375x667, iPhone 6/7/8 dimensions)
        driver.manage().window().setSize(new Dimension(375, 667));

        // Wait for the page to adjust to the new size
        wait.until(ExpectedConditions.presenceOfElementLocated(By.className("nav-logo")));  // Adjust to an appropriate condition

        // Add validation code for mobile size elements
        WebElement mobileMenu = driver.findElement(By.className("nav-logo"));
        Assert.assertTrue(mobileMenu.isDisplayed(), "The mobile menu should be visible on mobile size.");

        // Validate that the navigation logo is still visible
        WebElement mobileNavLogo = driver.findElement(By.className("nav-logo"));
        Assert.assertTrue(mobileNavLogo.isDisplayed(), "The navigation logo should still be visible on mobile size.");

        // Optionally, check for other mobile-specific elements
    }


    @Test
    public void TC_H_006() {
        long startTime = System.currentTimeMillis();
        driver.get("http://localhost:4200/home");
        long loadTime = System.currentTimeMillis() - startTime;

        Assert.assertTrue(loadTime < 3000, "Home page took too long to load");
    }

    @Test
    public void TC_H_007() {
        // Locate all the images within the slider using their img tag
        List<WebElement> imageElements = driver.findElements(By.xpath("//div[@class='slider']//img"));

        // Assert that each image is displayed
        for (WebElement image : imageElements) {
            Assert.assertTrue(image.isDisplayed(), "Image with src '" + image.getAttribute("src") + "' is not visible");

            // Optionally, you can also check if the image has a valid src attribute
            String imageUrl = image.getAttribute("src");
            Assert.assertNotNull(imageUrl, "Image does not have a valid src attribute.");
            Assert.assertTrue(imageUrl.startsWith("https://"), "Image URL is not valid: " + imageUrl);
        }
    }

    @Test
    public void TC_H_008() {
        WebElement loginButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']"));  // Adjust based on the actual element ID
        Assert.assertTrue(loginButton.isDisplayed(), "Login button is not present on the Home page");
    }

    @Test
    public void TC_H_009() {
        WebElement registerButton = driver.findElement(By.xpath("//button[@class='btn btn-info mb-4']")); // Adjust based on the actual element ID
        Assert.assertTrue(registerButton.isDisplayed(), "Register button is not present on the Home page");
    }

    @AfterMethod
    public void tearDown() {
        // Close the browser
        if (driver != null) {
            driver.quit();
        }
    }
}
